import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.StringWriter; 
import java.util.*; 
import java.text.DecimalFormat; 
import java.math.RoundingMode; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Koi extends PApplet {

// Evolution EcoSystem
// Daniel Shiffman <http://www.shiffman.net>
// The Nature of Code

// A World of creatures that eat food
// The more they eat, the longer they survive
// The longer they survive, the more likely they are to reproduce
// The bigger they are, the easier it is to land on food
// The bigger they are, the slower they are to find food
// When the creatures die, food is left behind



World world;
Network nn;
boolean doDraw;
boolean debug;
boolean looping;

public void setup() {
  

  //world = new World(100,0,0);
  world = new World(100, 3, 200);
  doDraw = true;
  debug = false;
  looping = true;
  
}

public void draw() {
  background(world.getSkyColor());
  try {
    world.run();
  } catch (Exception e){
    System.out.println(e.getMessage());
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    e.printStackTrace(pw);
    pw.flush();
    String stackTrace = sw.toString();
    System.out.println(stackTrace);
  }
}

// We can add a creature manually if we so desire
public void mousePressed() {
  world.birth(mouseX,mouseY);
}

public void mouseDragged() {
  world.birth(mouseX,mouseY);
}

public void keyReleased() {
  if (key == ' ') {
    doDraw = !doDraw;
  } else if (key == 'd') {
    debug = !debug;
  } else if (key == 's') {
    if (looping) {
      looping = !looping;
      noLoop();
    } else {
      looping = !looping;
      loop();
    }
  }
}
// EvolvedCreature class -- this is just like our Boid / Particle class
// the only difference is that it has DNA & fitness



class EvolvedCreature {
  //Neural Network stuff
  //int numFeelers = 8;
  int numFeelers = 5;
  //int inputCount = 2 + (numFeelers*2); // 8 numFeelers * 2 types (food and danger) + 1 time + 1 health
  int inputCount = 1 + (2*numFeelers) +2; // 8 numFeelers * 2 types (food and danger) + 1 time + 1 health
  int hiddenCount = 3; // Lol idk
  int outputCount = 2; // Left/Right + Move/Stay
  double learnRate = .8f;
  double momentum = .3f;

  // All of our physics stuff
  PVector location;
  PVector velocity;
  PVector acceleration;

  World w;
  float r;
  float lifetime;
  float birthday;
  int health;

  float fitness;
  int foodsEaten;

  Network brain;

  // Could make this part of DNA??)
  float maxspeed = 4.0f;
  float maxforce = 1.0f;

  int predatorPenalty = 50;
  int agingPenalty = 3;

  PVector previousLocation;
  PVector birthPlace;
  float totalDistanceCovered;
  double[] directions;

  //constructor
  EvolvedCreature(PVector l, World w) {
    acceleration = new PVector();
    velocity = new PVector(random(-1,1), random(-1,1));
    location = l.get();
    birthPlace = location.get();
    this.w = w;
    r = 5;
    lifetime = 0;
    foodsEaten = 0;
    birthday = millis();
    health = 1000;
    fitness = 0;
    totalDistanceCovered = 0;
    directions = new double[outputCount];
    directions[0] = 1;
    directions[1] = 1;
    brain = new Network(inputCount,hiddenCount,outputCount,learnRate,momentum);
  }

  EvolvedCreature(PVector l, World w, double[] m, double[] t) {
    this(l, w);
    brain.setThresholds(t);
    brain.setMatrix(m);
  }

  EvolvedCreature(PVector loc, PVector vel, World w) {
    this(loc, w);
    velocity = vel;
  }

  // FITNESS FUNCTION
  public void calcFitness(Food f) {
    float distanceToNearestFood = Float.MAX_VALUE;
    float distanceFromBirthplace = PVector.dist(location, birthPlace);
    totalDistanceCovered += PVector.dist(location, previousLocation);
    for(PVector p : f.getFood()) {
      float d = PVector.dist(location, p);
      if (d < distanceToNearestFood) distanceToNearestFood = d;
    }
    fitness = (50/distanceToNearestFood) + .1f*totalDistanceCovered + distanceFromBirthplace + 300*foodsEaten;
    //fitness = foodsEaten;
    //fitness = .1*distanceFromBirthplace + foodsEaten;
  }

  // Run in relation to all the obstacles
  // If I'm stuck, don't bother updating or checking for intersection
  public void run() {
    //if (!stopped) {
    if(doDraw) {
      display();
    }
    double[] senses = new double[inputCount];
    //PVector probe = PVector.mult(velocity, 1);
    PVector probe = velocity.copy();
    probe.normalize();
    probe.mult(5*r);
    probe.rotate(-1*0.785398f*3);
    for (int i = 0; i < numFeelers; ++i) {
      senses[i] = 0;
      probe.rotate(0.785398f);
      PVector shiftedProbe = PVector.add(probe, location);
      PVector shiftedProbe2 = PVector.add(PVector.mult(probe, 4),location);
      for (PVector f : w.getFood().getFood()) {
        senses[i] = (PVector.dist(shiftedProbe, f) < 4*r) ? 1:senses[i];
        senses[i+numFeelers] = (PVector.dist(shiftedProbe2, f) < 6*r) ? 1:senses[i];
      }
      //for (Predator o : w.getPredators()) {
        //senses[i+numFeelers] = (PVector.dist(shiftedProbe, o.location) < 4*r)? 1:senses[i+numFeelers];
      //}
      if (debug && (senses[i] == 1)) {
        ellipse(shiftedProbe.x, shiftedProbe.y, 4*r,4*r);
      }
      if (debug && (senses[i+numFeelers] == 1)) {
        ellipse(shiftedProbe2.x, shiftedProbe2.y, 6*r,6*r);
      }
    }
    /*
     *String sensesString = "";
     *for (int i = 0; i < numFeelers; ++i) {
     *  sensesString += senses[i];
     *}
     *if (sensesString == "0.00.00.00.00.00.00.00.0") {
     *  System.out.println(sensesString);
     *}
     */
    senses[2*numFeelers] = totalDistanceCovered;
    senses[2*numFeelers+1] = directions[0];
    senses[2*numFeelers+2] = directions[1];
    //senses[2*numFeelers] = health;
    //senses[2*numFeelers + 1] = w.getDayTime();

    lifetime = millis() - birthday;

    directions = brain.computeOutputs(senses);
    //System.out.println(directions[0] + ", " + directions[1]);
    update(directions[0]<0.5f?true:false,directions[1]<0.5f?true:false);
    calcFitness(w.getFood());

    // If I hit an edge or a predator
    borders();
    if (obstacles(w.predators)) {
      health -= predatorPenalty;
    } else {
      health -= agingPenalty;
    }
  }

  public void update(boolean move, boolean turnRight) {
    //System.out.println(move + " " + turnRight);
    // A little Reynolds steering here
    if (move) {
      //PVector desired = PVector.mult(velocity, 1);
      PVector desired = velocity.copy();
      desired.setMag(1);
      desired.rotate(turnRight ? -0.785398f : 0.785398f);
      desired.mult(maxspeed);

      //if(debug) {
        //line(location.x, location.y, location.x + velocity.x, location.y + velocity.y);
        //line(location.x, location.y, location.x + desired.x, location.y + desired.y);
      //}

      PVector steer = PVector.sub(desired,velocity);
      acceleration.add(steer);
      acceleration.limit(maxforce);
    }
    velocity.add(acceleration);
    velocity.limit(maxspeed);
    //previousLocation = PVector.mult(location, 1);
    previousLocation = location.copy();
    location.add(velocity);
    acceleration.mult(0);
    velocity.mult(0.9f);
  }

  public void eat(Food f) {
    ArrayList<PVector> food = f.getFood();
    // Are we touching any food objects?
    for (int i = food.size()-1; i >= 0; i--) {
      PVector foodLocation = food.get(i);
      float d = PVector.dist(location, foodLocation);
      // If we are, juice up our strength!
      if (d < r) {
        health += 200;
        //r++;
        foodsEaten++;
        food.remove(i);
      }
    }
  }

  // Did I hit an edge?
  public void borders() {
    float padding = 5;
    /*
     *if (location.x < 0-padding) {
     *  location.x = width+padding;
     *} else if (location.y < 0-padding) {
     *  location.y = height+padding;
     *} else if (location.x > width+padding) {
     *  location.x = 0-padding;
     *} else if (location.y > height+padding) {
     *  location.y = 0-padding;
     *}
     */
    if (location.x < 0-padding) {
      location.x = 0-padding;
    } else if (location.y < 0-padding) {
      location.y = 0-padding;
    } else if (location.x > width+padding) {
      location.x = width+padding;
    } else if (location.y > height+padding) {
      location.y = height+padding;
    }
  }

  public boolean obstacles(ArrayList<Predator> predators) {
    for (Predator p : predators) {
      if (PVector.dist(p.location,location) < 3*r) {
        return true;
      }
    }
    return false;
  }

  public boolean dead() {
    return health <= 0 ? true : false;
  }

  // At any moment there is a teeny, tiny chance a creature will reproduce
  public EvolvedCreature reproduce() {
    // asexual reproduction
    if (random(1) < 0.0005f) {
      // Child is exact copy of single parent
      double[] m = brain.getMatrix();
      double[] t = brain.getThresholds();
      // Child DNA can mutate
      m = brain.mutate(0.01f, m);
      t = brain.mutate(0.01f, t);
      return new EvolvedCreature(location,w,m,t);
    }
    else {
      return null;
    }
  }

  // At any moment there is a teeny, tiny chance a bloop will reproduce
  public EvolvedCreature forceBreed() {
    // Child is exact copy of single parent
    double[] m = brain.getMatrix();
    double[] t = brain.getThresholds();
    DecimalFormat df = new DecimalFormat("#.##");
    df.setRoundingMode(RoundingMode.CEILING);

/*
 *    System.out.println("---------------------------");
 *    System.out.print("m: ");
 *    for (int i = 0; i < m.length; i++) {
 *      System.out.print(df.format(m[i]) + ", ");
 *    }
 *    System.out.println();
 *
 *    System.out.print("t: ");
 *    for (int i = 0; i < t.length; i++) {
 *      System.out.print(df.format(t[i]) + ", ");
 *    }
 *    System.out.println();
 *    System.out.println();
 */

    // Child DNA can mutate
    m = brain.mutate(0.10f, m);
    t = brain.mutate(0.10f, t);
/*
 *    System.out.print("mm: ");
 *    for (int i = 0; i < m.length; i++) {
 *      System.out.print(df.format(m[i]) + ", ");
 *    }
 *    System.out.println();
 *
 *    System.out.print("tm: ");
 *    for (int i = 0; i < t.length; i++) {
 *      System.out.print(df.format(t[i]) + ", ");
 *    }
 *    System.out.println();
 */
    return new EvolvedCreature(new PVector(random(width),random(height)),w,m,t);
  }

  public void display() {
    //fill(0,150);
    //stroke(0);
    //ellipse(location.x,location.y,r,r);
    if (debug) {
      line(location.x, location.y, birthPlace.x, birthPlace.y);
    }
    float theta = velocity.heading() + PI/2;
    fill(200,map(health,0,1200,0,255));
    stroke(0);
    pushMatrix();
    translate(location.x,location.y);
    rotate(theta);
    beginShape(TRIANGLES);
    vertex(0, -r*2);
    vertex(-r, r*2);
    vertex(r, r*2);
    endShape();
    popMatrix();
  }

  public void highlight() {
    stroke(0);
    fill(255,0,0,50);
    ellipse(location.x,location.y,32,32);

  }

  public float getFitness() {
    return fitness;
  }

}
// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Evolution EcoSystem

// A collection of food in the world

class Food {
  ArrayList<PVector> food;
 
  Food(int num) {
    // Start with some food
    food = new ArrayList();
    for (int i = 0; i < num; i++) {
       food.add(new PVector(random(width),random(height))); 
    }
  } 
  
  // Add some food at a location
  public void add(PVector l) {
     food.add(l.get()); 
  }
  
  // Display the food
  public void run() {
    for (PVector f : food) {
       rectMode(CENTER);
       stroke(0);
       fill(175);
       rect(f.x,f.y,8,8);
    } 
    
    // There's a small chance food will appear randomly
    if (random(1) < 0.001f) {
       food.add(new PVector(random(width),random(height))); 
       //food.remove(random(0,food.size()-1)); 
    }
  }
  
  // Return the list of food
  public ArrayList<PVector> getFood() {
    return food; 
  }
}
class HibernatingState extends State {
  float wanderTheta;

  HibernatingState(World w, Predator p) {
    super(w,p);
    wanderTheta = 0;
  }

  public State update() {
    e.setFillColor(State.HIBERNATING_COLOR);
    e.health += 1;
    if (w.getDayTime() > 2*w.lengthOfDay/w.numSkyColors) return new HuntingState(w,e);
    return this;
  }

  public PVector steer() {
    return new PVector(0,0);
  }

  public void move(PVector steeringForce) {
    e.velocity.mult(0.99f);
  }
}
class HuntingState extends State {

  int numEaten;

  HuntingState(World w, Predator p) {
    super(w,p);
    numEaten = 0;
  }

  public State update() {
    e.setFillColor(State.HUNTING_COLOR);
    PVector steerForce = steer();
    move(steerForce);
    if (eat(w.getCreatures())) {
      numEaten++;
    }
    if (numEaten > 10) {
      return new WanderingState(w,e);
    }
    return this;
  }

  public PVector steer() {
    if (!w.getCreatures().isEmpty()) {
        //Seed with first food
        PVector target = w.getCreatures().get(0).location.copy();
        //Find closest food
        for (EvolvedCreature closestCreature : w.getCreatures()) {
          PVector closestCreatureLocation = closestCreature.location;
            if (PVector.dist(target, e.location) > PVector.dist(closestCreatureLocation, e.location)) {
                target = closestCreatureLocation;
            }
        }

        PVector desired = PVector.sub(target,e.location);
        desired.normalize();
        desired.mult(e.maxspeed);
        PVector steer = PVector.sub(desired,e.velocity);
        return steer;
    } else {
      return new PVector(width/2, height/2);
    }
  }

  public void move(PVector steeringForce) {
    e.acceleration.add(steeringForce);
    e.acceleration.limit(e.maxforce);

    e.velocity.add(e.acceleration);
    e.velocity.limit(e.maxspeed);
    e.location.add(e.velocity);
    e.acceleration.mult(0);
  }

  public boolean eat(ArrayList<EvolvedCreature> food) {
    //In this method, food refers to the Predators food (a creature) not a food object
    for (int i = food.size()-1; i >= 0; i--) {
      PVector foodLocation = food.get(i).location.copy();
      float d = PVector.dist(e.location, foodLocation);
      if (d < e.r) {
        food.remove(i);
        e.health += 200;
        return true;
      }
    }
    return false;
  }
}
/**
 * Neural Network
 * Feedforward Backpropagation Neural Network
 * Written in 2002 by Jeff Heaton(http://www.jeffheaton.com)
 *
 * This class is released under the limited GNU public
 * license (LGPL).
 *
 * @author Jeff Heaton
 * @version 1.0
 */

public class Network {

  /**
   * The global error for the training.
   */
  protected double globalError;

  /**
   * The number of input neurons.
   */
  protected int inputCount;

  /**
   * The number of hidden neurons.
   */
  protected int hiddenCount;

  /**
   * The number of output neurons
   */
  protected int outputCount;

  /**
   * The total number of neurons in the network.
   */
  protected int neuronCount;

  /**
   * The number of weights in the network.
   */
  protected int weightCount;

  /**
   * The learning rate.
   */
  protected double learnRate;

  /**
   * The outputs from the various levels.
   */
  protected double fire[];

  /**
   * The weight matrix this, along with the thresholds can be
   * thought of as the "memory" of the neural network.
   */
  protected double matrix[];

  /**
   * The errors from the last calculation.
   */
  protected double error[];

  /**
   * Accumulates matrix delta's for training.
   */
  protected double accMatrixDelta[];

  /**
   * The thresholds, this value, along with the weight matrix
   * can be thought of as the memory of the neural network.
   */
  protected double thresholds[];

  /**
   * The changes that should be applied to the weight
   * matrix.
   */
  protected double matrixDelta[];

  /**
   * The accumulation of the threshold deltas.
   */
  protected double accThresholdDelta[];

  /**
   * The threshold deltas.
   */
  protected double thresholdDelta[];

  /**
   * The momentum for training.
   */
  protected double momentum;

  /**
   * The changes in the errors.
   */
  protected double errorDelta[];


  /**
   * Construct the neural network.
   *
   * @param inputCount The number of input neurons.
   * @param hiddenCount The number of hidden neurons
   * @param outputCount The number of output neurons
   * @param learnRate The learning rate to be used when training.
   * @param momentum The momentum to be used when training.
   */
  public Network(int inputCount,
      int hiddenCount,
      int outputCount,
      double learnRate,
      double momentum) {

    this.learnRate = learnRate;
    this.momentum = momentum;

    this.inputCount = inputCount;
    this.hiddenCount = hiddenCount;
    this.outputCount = outputCount;
    neuronCount = inputCount + hiddenCount + outputCount;
    weightCount = (inputCount * hiddenCount) + (hiddenCount * outputCount);

    fire    = new double[neuronCount];
    matrix   = new double[weightCount];
    matrixDelta = new double[weightCount];
    thresholds = new double[neuronCount];
    errorDelta = new double[neuronCount];
    error    = new double[neuronCount];
    accThresholdDelta = new double[neuronCount];
    accMatrixDelta = new double[weightCount];
    thresholdDelta = new double[neuronCount];

    reset();
  }



  /**
   * Returns the root mean square error for a complet training set.
   *
   * @param len The length of a complete training set.
   * @return The current error for the neural network.
   */
  public double getError(int len) {
    double err = Math.sqrt(globalError / (len * outputCount));
    globalError = 0; // clear the accumulator
    return err;

  }

  /**
   * The threshold method. You may wish to override this class to provide other
   * threshold methods.
   *
   * @param sum The activation from the neuron.
   * @return The activation applied to the threshold method.
   */
  public double threshold(double sum) {
    return 1.0f / (1 + Math.exp(-1.0f * sum));
  }

  /**
   * Compute the output for a given input to the neural network.
   *
   * @param input The input provide to the neural network.
   * @return The results from the output neurons.
   */
  public double []computeOutputs(double input[]) {
    int i, j;
    final int hiddenIndex = inputCount;
    final int outIndex = inputCount + hiddenCount;

    for (i = 0; i < inputCount; i++) {
      fire[i] = input[i];
    }

    // first layer
    int inx = 0;

    for (i = hiddenIndex; i < outIndex; i++) {
      double sum = thresholds[i];

      for (j = 0; j < inputCount; j++) {
        sum += fire[j] * matrix[inx++];
      }
      fire[i] = threshold(sum);
    }

    // hidden layer

    double result[] = new double[outputCount];

    for (i = outIndex; i < neuronCount; i++) {
      double sum = thresholds[i];

      for (j = hiddenIndex; j < outIndex; j++) {
        sum += fire[j] * matrix[inx++];
      }
      fire[i] = threshold(sum);
      result[i-outIndex] = fire[i];
    }

    return result;
  }


  /**
   * Calculate the error for the recogntion just done.
   *
   * @param ideal What the output neurons should have yielded.
   */
  public void calcError(double ideal[]) {
    int i, j;
    final int hiddenIndex = inputCount;
    final int outputIndex = inputCount + hiddenCount;

    // clear hidden layer errors
    for (i = inputCount; i < neuronCount; i++) {
      error[i] = 0;
    }

    // layer errors and deltas for output layer
    for (i = outputIndex; i < neuronCount; i++) {
      error[i] = ideal[i - outputIndex] - fire[i];
      globalError += error[i] * error[i];
      errorDelta[i] = error[i] * fire[i] * (1 - fire[i]);
    }

    // hidden layer errors
    int winx = inputCount * hiddenCount;

    for (i = outputIndex; i < neuronCount; i++) {
      for (j = hiddenIndex; j < outputIndex; j++) {
        accMatrixDelta[winx] += errorDelta[i] * fire[j];
        error[j] += matrix[winx] * errorDelta[i];
        winx++;
      }
      accThresholdDelta[i] += errorDelta[i];
    }

    // hidden layer deltas
    for (i = hiddenIndex; i < outputIndex; i++) {
      errorDelta[i] = error[i] * fire[i] * (1 - fire[i]);
    }

    // input layer errors
    winx = 0; // offset into weight array
    for (i = hiddenIndex; i < outputIndex; i++) {
      for (j = 0; j < hiddenIndex; j++) {
        accMatrixDelta[winx] += errorDelta[i] * fire[j];
        error[j] += matrix[winx] * errorDelta[i];
        winx++;
      }
      accThresholdDelta[i] += errorDelta[i];
    }
  }

  /**
   * Modify the weight matrix and thresholds based on the last call to
   * calcError.
   */
  public void learn() {
    int i;

    // process the matrix
    for (i = 0; i < matrix.length; i++) {
      matrixDelta[i] = (learnRate * accMatrixDelta[i]) + (momentum * matrixDelta[i]);
      matrix[i] += matrixDelta[i];
      accMatrixDelta[i] = 0;
    }

    // process the thresholds
    for (i = inputCount; i < neuronCount; i++) {
      thresholdDelta[i] = learnRate * accThresholdDelta[i] + (momentum * thresholdDelta[i]);
      thresholds[i] += thresholdDelta[i];
      accThresholdDelta[i] = 0;
    }
  }

  /**
   * Reset the weight matrix and the thresholds.
   */
  public void reset() {
    int i;

    for (i = 0; i < neuronCount; i++) {
      //thresholds[i] = 0.5 - (Math.random());
      thresholds[i] = random(-0.5f,0.5f);
      thresholdDelta[i] = 0;
      accThresholdDelta[i] = 0;
    }
    for (i = 0; i < matrix.length; i++) {
      //matrix[i] = 0.5 - (Math.random());
      matrix[i] = random(-0.5f,0.5f);
      matrixDelta[i] = 0;
      accMatrixDelta[i] = 0;
    }
  }

  public double[] getMatrix() {
    double[] c = new double[matrix.length];
    arrayCopy(matrix, c);
    return c;
  }

  public double[] getThresholds() {
    double[] c = new double[thresholds.length];
    arrayCopy(thresholds, c);
    return c;
  }

  public void setThresholds(double[] t) {
    //if (t.length != thresholds.length) {
    //  System.out.println(t.length);
    //  System.out.println(thresholds.length);
    //}
    arrayCopy(t,thresholds);
  }

  public void setMatrix(double[] m) {
    arrayCopy(m,matrix);
  }

  public double[] mutate(float m, double[] genes) {
    for (int i = 0; i < genes.length; i++) {
      if (random(1) < m) {
        genes[i] = random(-1,1);
      }
    }
    return genes;
  }

}
class Predator {
    PVector location;
    PVector velocity;
    PVector acceleration;

    float r;
    int fillColor;
    int edgeColor;

    int health;

    float maxspeed = 2.0f;
    float maxforce = 0.5f;

    State state;

    World w;

    Predator(PVector l, World w) {
        this.w = w;
        this.state = new HuntingState(w,this);
        location = l.copy();
        velocity = new PVector( random(width), random(height) ).normalize().mult(maxspeed);
        acceleration = new PVector();
        r = 7;
        health = 1000;
    }

    public void run() {
        // Move / steer / change state
        this.state = state.update();
        this.health -= 2;
        // If I hit an edge, stop
        borders();
        // Draw me!
        display();
    }

    // If I hit an edge, stop
    public void borders() {
        float padding = 5;
        if (location.x < 0-padding) {
            location.x = 0-padding;
        } else if (location.y < 0-padding) {
            location.y = 0-padding;
        } else if (location.x > width+padding) {
            location.x = width+padding;
        } else if (location.y > height+padding) {
            location.y = height+padding;
        }
    }

    public void setFillColor(int c) {
        fillColor = c;
    }

    public void setEdgeColor(int c) {
        edgeColor = c;
    }

    public void display() {
        float theta = velocity.heading() + PI/2;
        fill(fillColor);
        stroke(edgeColor);
        pushMatrix();
        translate(location.x,location.y);
        rotate(theta);
        beginShape(TRIANGLES);
        vertex(0, -r*2);
        vertex(-r, r*2);
        vertex(r, r*2);
        endShape();
        popMatrix();
    }

    public void highlight() {
        stroke(0);
        fill(255,0,0,100);
        ellipse(location.x,location.y,16,16);
    }
}
abstract class State {
  //final static State HUNTING_STATE = new HuntingState();

  final static int HUNTING_COLOR = 0xffDFDA75;
  final static int WANDER_COLOR = 0xff00FFFF;
  final static int CHARGING_COLOR = 0xffFF0000;
  final static int HIBERNATING_COLOR = 0xff0000FF;

  World w;
  Predator e;

  State (World w, Predator p) {
    this.w = w;
    this.e = p;
  }


  public abstract State update();
  public abstract PVector steer();
  public abstract void move(PVector v);
}
class WanderingState extends State {
  float wanderTheta;

  WanderingState(World w, Predator p) {
    super(w,p);
    wanderTheta = 0;
  }

  public State update() {
    e.setFillColor(State.WANDER_COLOR);
    PVector steerForce = steer();
    move(steerForce);
    eat(w.getCreatures());
    if (e.health < 100 || w.getDayTime() < w.lengthOfDay/w.numSkyColors ) return new HibernatingState(w,e);
    return this;
  }

  public PVector steer() {
    float wanderR = 10;         // Radius for our "wander circle"
    float wanderD = 80;         // Distance for our "wander circle"
    float change = 0.1f;
    wanderTheta += random(-change,change);     // Randomly change wander theta

    // Now we have to calculate the new location to steer towards on the wander circle
    PVector circleloc = e.velocity.get();    // Start with velocity
    circleloc.normalize();            // Normalize to get heading
    circleloc.mult(wanderD);          // Multiply by distance
    circleloc.add(e.location);               // Make it relative to boid's location
    
    float h = e.velocity.heading2D();        // We need to know the heading to offset wanderTheta

    PVector circleOffSet = new PVector(wanderR*cos(wanderTheta+h),wanderR*sin(wanderTheta+h));
    PVector target = PVector.add(circleloc,circleOffSet);

    if(debug) drawWanderStuff(e.location, circleloc, target, wanderR);

    PVector desired = PVector.sub(target,e.location);
    desired.normalize();
    desired.mult(e.maxspeed);
    PVector steer = PVector.sub(desired,e.velocity);
    return steer;
  }

  public void move(PVector steeringForce) {
    e.acceleration.add(steeringForce);
    e.acceleration.limit(e.maxforce);

    e.velocity.add(e.acceleration);
    e.velocity.limit(e.maxspeed);
    e.location.add(e.velocity);
    e.acceleration.mult(0);
  }

  public boolean eat(ArrayList<EvolvedCreature> food) {
    //In this method, food refers to the Predators food (a creature) not a food object
    for (int i = food.size()-1; i >= 0; i--) {
      PVector foodLocation = food.get(i).location.copy();
      float d = PVector.dist(e.location, foodLocation);
      if (d < e.r) {
        food.remove(i);
        e.health += 100;
        return true;
      }
    }
    return false;
  }

  public void drawWanderStuff(PVector location, PVector circle, PVector target, float rad) {
    stroke(0); 
    noFill();
    ellipseMode(CENTER);
    ellipse(circle.x,circle.y,rad*2,rad*2);
    ellipse(target.x,target.y,4,4);
    line(location.x,location.y,circle.x,circle.y);
    line(circle.x,circle.y,target.x,target.y);
  }

}
// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Evolution Ecosystem

// The World we live in Has bloops and food


class World {

  ArrayList<EvolvedCreature> creatures;
  ArrayList<Predator> predators;
  Set<EvolvedCreature> hallOfFame;
  Food food;
  int initialNumberOfCreatures;
  int initialNumberOfPredators;
  int initialNumberOfFood;
  public Comparator<EvolvedCreature> EVCComparator = new Comparator<EvolvedCreature>() {
			@Override
			public int compare(EvolvedCreature l1, EvolvedCreature l2) {
				float w1 = l1.getFitness();
				float w2 = l2.getFitness();
				if (w1 - w2 > 0)
					return -1;
				if (w1 - w2 < 0)
					return 1;
				return 0;
			}
		};

  int generation;
  float generationAverageLifeTime;
  int generationDeaths;
  SortedSet<EvolvedCreature> bestOfGen;

  float bigBangTime;
  float startOfTheDay;
  float lengthOfDay = (24f * 1000 * 4);

  int numSkyColors = 3;
  int skyBlue = color(163, 220, 239);
  int sunsetRed = color(255, 137, 102);
  int midnightBlue = color(40, 13, 55);

  PrintWriter outputFile;

  // Constructor
  World(int c, int p, int f) {
    initialNumberOfCreatures = c;
    initialNumberOfPredators = p;
    initialNumberOfFood = f;
    // Start with initial food and creatures
    creatures = new ArrayList<EvolvedCreature>();
    predators = new ArrayList<Predator>();
    hallOfFame = new TreeSet<EvolvedCreature>(EVCComparator);
    for (int i = 0; i < initialNumberOfCreatures; i++) {
      PVector l = new PVector(random(width),random(height));
      PVector v = new PVector(random(width),random(height));
      creatures.add(new EvolvedCreature(l,v,this));
    }
    for (int i = 0; i < initialNumberOfPredators; i++) {
      PVector l = new PVector(random(width),random(height));
      predators.add(new Predator(l,this));
    }
    food = new Food(initialNumberOfFood);
    bigBangTime = millis();
    startOfTheDay = 0;
    generation = 0;
    generationDeaths = 0;
    bestOfGen = new TreeSet<EvolvedCreature>(EVCComparator);
    outputFile = createWriter(month() + "-" + day() + "-"  + year() + ":"  + hour() + "-"  + minute() + "-"  + second());
  }

  public float getDayTime() {
    /*
     *float dayTime = getSimulationTime() - startOfTheDay;
     *float lengthOfDay = 24f * 1000 * 4;
     *if dayTime >= lengthOfDay {
     *  startOfTheDay = getSimulationTime();
     *  return dayTime;
     *} else {
     *  return dayTime;
     *}
     */
    return getSimulationTime() % lengthOfDay;
  }

  public int getSkyColor() {
    float time = getDayTime();
    if (time < lengthOfDay/numSkyColors) {
      return lerpColor(skyBlue, sunsetRed, map(time, 0, lengthOfDay/numSkyColors, 0.0f, 1.0f));
    } else if (time < 2*lengthOfDay/numSkyColors) {
      return lerpColor(sunsetRed, midnightBlue, map(time, lengthOfDay/numSkyColors, 2*lengthOfDay/numSkyColors, 0.0f, 1.0f));
    } else {
      return lerpColor(midnightBlue, skyBlue, map(time, 2*lengthOfDay/numSkyColors, lengthOfDay, 0.0f, 1.0f));
    }
  }

  public float getSimulationTime() {
    return millis() - bigBangTime;
  }

  public ArrayList<EvolvedCreature> getCreatures() {
    return creatures;
  }

  public ArrayList<Predator> getPredators() {
    return predators;
  }

  public Food getFood() {
    return food;
  }

  // Make a new creature
  public void birth(float x, float y) {
    PVector l = new PVector(x,y);
    EvolvedCreature baby = new EvolvedCreature(l,this);
    baby.velocity = new PVector(random(-1,1),random(-1,1));
    creatures.add(baby);
  }

  // Run the world
  public void run() {
    // Deal with food
    food.run();

    // Cycle through the ArrayList of creatures backwards b/c we are deleting
    for (int i = predators.size() - 1; i >= 0; i--) {
      Predator p = predators.get(i);
      p.run();
    }
    // Cycle through the ArrayList of creatures backwards b/c we are deleting
    for (int i = creatures.size() - 1; i >= 0; i--) {
      // All bloops run and eat
      EvolvedCreature b = creatures.get(i);
      b.run();
      b.eat(food);
      if (debug) {
        fill(0);
        text(b.getFitness(), b.location.x, b.location.y);
      }
      // If it's dead, kill it and make food
      if (b.dead()) {
        generationAverageLifeTime += b.lifetime;
        generationDeaths++;
        hallOfFame.add(b);
        //System.out.println("Added: " + b.getFitness());
        creatures.remove(i);
        food.add(b.location);
      }
      bestOfGen.add(b);
      // Perhaps this bloop would like to make a baby?
      EvolvedCreature child = b.reproduce();
      if (child != null) creatures.add(child);
    }
    //Highlight the best of each generation
    if (debug) {
      try {
        EvolvedCreature BOG = bestOfGen.first();
        BOG.highlight();
      } catch (NoSuchElementException e) { }
    }

    //Repopulate from the survivors if population gets low
    //if (creatures.size()<=initialNumberOfCreatures*.2) {
    if (creatures.size()<=1) {
      //outputFile.println(generation + ":" + generationAverageLifeTime/generationDeaths);
      predators.clear();
      for (int i = 0; i < initialNumberOfPredators; i++) {
        PVector l = new PVector(random(width),random(height));
        predators.add(new Predator(l,this));
      }
      outputFile.println(generation + "," + bestOfGen.first().getFitness());
      outputFile.flush();
      //outputFile.close();
      generationDeaths = 0;
      generationAverageLifeTime = 0;
      generation++;
      if (creatures.size() == 1) {
        creatures.add(creatures.get(0).forceBreed());
        creatures.add(creatures.get(0).forceBreed());
        creatures.add(creatures.get(0).forceBreed());
      }
      while (creatures.size() <= initialNumberOfCreatures) {
        //for (int i = creatures.size() - 1; i >= 0; i--) {
          //EvolvedCreature child = creatures.get(i).forceBreed();
          //if (child != null) creatures.add(child);
        //}
        int QSize = hallOfFame.size() < 5 ? hallOfFame.size() : 5;
        TreeSet<EvolvedCreature> tempQ = new TreeSet<EvolvedCreature>(EVCComparator);
        Iterator<EvolvedCreature> itr = hallOfFame.iterator();
        for (int i = 0; i < QSize; i++) {
          EvolvedCreature parent = itr.next();
          System.out.print(parent.getFitness()+ " ");
          tempQ.add(parent);

          EvolvedCreature child = parent.forceBreed();
          if (child != null) creatures.add(child);
        }
        System.out.println();
        hallOfFame.clear();
        hallOfFame = tempQ;
        //PVector l = new PVector(random(width),random(height));
        //PVector v = new PVector(random(width),random(height));
        //creatures.add(new EvolvedCreature(l,v));
        //l = new PVector(random(width),random(height));
        //v = new PVector(random(width),random(height));
        //creatures.add(new EvolvedCreature(l,v));
        try{
          EvolvedCreature BOG = bestOfGen.first();
          creatures.add(BOG.forceBreed());
          bestOfGen.remove(BOG);
        } catch (NoSuchElementException e) { }
      }
      food = new Food(initialNumberOfFood);
      bestOfGen.clear();
    }

    displayData();
  }

  public void displayData() {
    fill(0);
    text("Generation: " + generation,0,10);
    text("Time of Day: " + getDayTime(),0,20);
    text("Number of Creatures: " + creatures.size(),0,30);
  }
}
  public void settings() {  size(1280, 720);  noSmooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Koi" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
